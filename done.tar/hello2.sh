#! /bin/bash

echo "Hello iadejare!"
curl https://api.github.com/users/iadejare