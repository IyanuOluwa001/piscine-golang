#! /bin/bash

echo "Hello iadejare!"